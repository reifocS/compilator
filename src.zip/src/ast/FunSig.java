package ast;

public class FunSig {
}
