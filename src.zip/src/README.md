Victor Leiglat, Vincent Escoffier.


**Etat d'avancement**  
piste verte et piste bleue partie 3 (syntaxe infixe plus typage).  
Tous les test passent (sauf les tests divisions / zero de la piste verte).