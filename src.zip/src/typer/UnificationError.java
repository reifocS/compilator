package typer;

public class UnificationError extends RuntimeException {
}
