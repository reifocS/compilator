package typer;

public enum TypeSym {
    INT, BOOL
}
