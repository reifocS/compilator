package typer;

public class SemanticError extends RuntimeException {
    public SemanticError(String msg) {
        super(msg);
    }
}
