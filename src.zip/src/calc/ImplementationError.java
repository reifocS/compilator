package calc;

public class ImplementationError extends RuntimeException {
    public ImplementationError(){
        super();
    }
}
