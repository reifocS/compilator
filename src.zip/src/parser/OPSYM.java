package parser;

public enum OPSYM {
    PLUS, DIVIDE, MINUS, TIMES, SUPERIOR, INFERIOR, EQUALS;

    public static OPSYM parseOP(String s) {
        switch (s) {
            case "+" -> {
                return PLUS;
            }
            case "-" -> {
                return MINUS;
            }
            case "*" -> {
                return TIMES;
            }
            case "/" -> {
                return DIVIDE;
            }
            case ">" -> {
                return SUPERIOR;
            }
            case "<" -> {
                return INFERIOR;
            }
            case "==" -> {
                return EQUALS;
            }
            default -> {
                return null;
            }

        }
    }
}
