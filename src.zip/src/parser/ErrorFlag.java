package parser;

public class ErrorFlag {
    private static boolean flag = false;

    private ErrorFlag() {}

    static void setFlag() {
        flag = true;
    }

    public static void reset() {
        flag = false;
    }
}
