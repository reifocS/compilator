package parser;

import ast.AST;

public class ASTVisitor extends CalcBaseVisitor<AST> {

    public AST visitIntLit(CalcParser.IntLitContext ctx) {
        return new IntLit(Integer.parseInt(ctx.getText()));
    }

    @Override
    public AST visitVar(CalcParser.VarContext ctx) {
        return new Var(ctx.getText());
    }

    @Override
    public AST visitUnExp(CalcParser.UnExpContext ctx) {
        AST a1 = visit(ctx.expression());
        if (ctx.tail().expression() != null) {
            AST a2 = visit(ctx.tail().expression());
            OPSYM op = OPSYM.MINUS;
            return new BinExp(op, a1, a2);
        }
        return new UnExp(a1);
    }

    @Override
    public AST visitBinExp(CalcParser.BinExpContext ctx) {
        var expressions = ctx.expression();
        OPSYM op = OPSYM.parseOP(ctx.OP().getText());
        AST exp1 = visit(expressions.get(0));
        AST exp2 = visit(expressions.get(1));
        return new BinExp(op, exp1, exp2);
    }

    @Override
    public AST visitCondExp(CalcParser.CondExpContext ctx) {
        var expressions = ctx.expression();
        AST exp1 = visit(expressions.get(0));
        AST exp2 = visit(expressions.get(1));
        AST exp3 = visit(expressions.get(2));
        return new CondExp(exp1, exp2, exp3);
    }
}
