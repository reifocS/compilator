package parser;

import ast.AST;

public class BinExp extends AST {
    private final OPSYM operator;
    private final AST exp1;
    private final AST exp2;

    public BinExp(OPSYM operator, AST exp1, AST exp2) {
        this.operator = operator;
        this.exp1 = exp1;
        this.exp2 = exp2;
    }

    @Override
    public String toString() {
        return "BinExp{" +
                "operator=" + operator +
                ", exp1=" + exp1 +
                ", exp2=" + exp2 +
                '}';
    }

    @Override
    public int eval(State<Integer> s) {
        int val1 = exp1.eval(s);
        int val2 = exp2.eval(s);
        if (operator.equals(OPSYM.PLUS))
            return val1 + val2;
        if (operator.equals(OPSYM.MINUS))
            return val1 - val2;
        if (operator.equals(OPSYM.TIMES))
            return val1 * val2;
        if (operator.equals(OPSYM.INFERIOR))
            return val1 < val2 ? 1 : 0;
        if (operator.equals(OPSYM.SUPERIOR))
            return val1 > val2 ? 1 : 0;
        if (operator.equals(OPSYM.DIVIDE))
            return val1 / val2;
        if (operator.equals(OPSYM.EQUALS))
            return val1 == val2 ? 1 : 0;
        return 0;
    }
}
