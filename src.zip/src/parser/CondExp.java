package parser;

import ast.AST;

public class CondExp extends AST {
    private final AST exp1;
    private final AST exp2;
    private final AST exp3;

    public CondExp(AST exp1, AST exp2, AST exp3) {
        this.exp1 = exp1;
        this.exp2 = exp2;
        this.exp3 = exp3;
    }

    @Override
    public String toString() {
        return "CondExp{" +
                "exp1=" + exp1 +
                ", exp2=" + exp2 +
                ", exp3=" + exp3 +
                '}';
    }

    @Override
    public int eval(State<Integer> s) {
        if (exp1.eval(s) != 0)
            return exp2.eval(s);
        return exp3.eval(s);
    }
}
