package parser;


import ast.AST;

public class UnExp extends AST {
    private final AST exp;

    public UnExp(AST exp) {
        this.exp = exp;
    }

    @Override
    public String toString() {
        return "UnExp{" +
                "exp=" + exp +
                '}';
    }

    public int eval(State<Integer> t) {
        return exp.eval(t);
    }
}
