package parser;

import ast.AST;

public class IntLit extends AST {
    private int integer;

    public IntLit(int integer) {
        this.integer = integer;
    }

    @Override
    public String toString() {
        return "IntLit{" +
                "integer=" + integer +
                '}';
    }

    public int eval(State<Integer> s) {
        return integer;
    }
}
