package parser;

import ast.AST;

public class Var extends AST {
    private String text;

    public Var(String text) {
        super();
        this.text = text;
    }

    public int eval(State<Integer> t) {
        return t.lookup(text);
    }
}
